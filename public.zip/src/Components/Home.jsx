import React from 'react';
import '../Styles/Home.css';
import car from '../Assets/car-removebg-preview.png';
import animation from '../Assets/Animation.png'

const Home = () => {
  return (
    <div className='container'>
      <div className="home-section">
        <img src={animation} class="" alt="" />
        <img src={car} alt="" className="car-img" />
      </div>

      <div className='green'>

        <div className="progress">
          
        </div>
      </div>
      
    </div>
  );
};

export default Home;
